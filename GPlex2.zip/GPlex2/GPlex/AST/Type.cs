﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPlex.AST
{
    public abstract class Type : Node { }
    public class ArrayType : Type
    {
        private Type ElementType;
        public ArrayType(Type ElementType) { this.ElementType = ElementType; }
        public override bool ResolveNames()
        {
            return true;
        }
    }
    public class NamedType : Type
    {
        private string Typename;
        public NamedType(string Typename) { this.Typename = Typename; }
        public override bool ResolveNames()
        {
            return true;
        }
    }
}
