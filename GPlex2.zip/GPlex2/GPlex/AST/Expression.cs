﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPlex.AST
{
    public abstract class Expression : Node { };
    public class PrimaryExpression : Expression
    {
        private int ValueofPE;
        public PrimaryExpression(int ValueofPE) { this.ValueofPE = ValueofPE; }
        public override bool ResolveNames()
        {
            return true;
        }
    }
    public class ExpressionName : Expression
    {
        private string Identifier;
        public ExpressionName(string Identifier) { this.Identifier = Identifier; }
        public override bool ResolveNames()
        {
            return true;
        }
    }
    public class AssignmentExpression : ExpressionStatement
    {
        private Expression lhs, rhs;
        private int AssignmentOperator;
        public AssignmentExpression(Expression lhs, int AssignmentOperator, Expression rhs)
        { this.lhs = lhs; this.AssignmentOperator = AssignmentOperator; this.rhs = rhs; }
        public override bool ResolveNames()
        {
            return lhs.ResolveNames() && rhs.ResolveNames();
        }
    }
}
