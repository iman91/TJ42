﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPLexTutorial.AST
{
    public abstract class Statements : Node { };
    public class ExpressionStatement : Statements
    {
        private Expression expr;

        public ExpressionStatement(Expression expr)
        {
            this.expr = expr;
        }
        public override bool ResolveNames(LexicalScope scope)
        {
            return expr.ResolveNames(scope);
        }
        public override void TypeCheck()
        {
            
        }
    }
    public class WhileStatement : Statements
    {
        private Expression cond;
        private Statements stmt;
        public WhileStatement(Expression cond, Statements stmt)
        {
            this.cond = cond;
            this.stmt = stmt;
        }
        public override bool ResolveNames(LexicalScope scope)
        {
            return cond.ResolveNames(scope);
        }
        public override void TypeCheck()
        {
            cond.TypeCheck();
            if (!cond.type.Equal(new BoolType()))
            { 
                Console.WriteLine("Invalid type for while statement condition");
                throw new Exception("TypeCheck error");
            }
            stmt.TypeCheck();
        }
    }
    public class DoStatement : Statements
    {
        private Expression expr;
        private Statements stmts;
        public DoStatement(Expression expr, Statements stmts)
        {
            this.expr = expr;
            this.stmts = stmts;
        }
        public override bool ResolveNames(LexicalScope scope)
        {
            return expr.ResolveNames(scope);
        }
        public override void TypeCheck()
        {
            expr.TypeCheck();
            stmts.TypeCheck();
        }
    }
    public class BreakStatement : Statements
    {
        private Expression expr;
        private Statements stmts;
        public BreakStatement(Expression expr, Statements stmts)
        {
            this.expr = expr;
            this.stmts = stmts;
        }
        public override bool ResolveNames(LexicalScope scope)
        {
            return expr.ResolveNames(scope);
        }
        public override void TypeCheck()
        {
            expr.TypeCheck();
            stmts.TypeCheck();
        }
    }
    public class ContinueStatement : Statements
    {
        private Expression expr;
        private Statements stmts;
        public ContinueStatement(Expression expr, Statements stmts)
        {
            this.expr = expr;
            this.stmts = stmts;
        }
        public override bool ResolveNames(LexicalScope scope)
        {
            return expr.ResolveNames(scope);
        }
        public override void TypeCheck()
        {
            expr.TypeCheck();
            stmts.TypeCheck();
        }
    }
    public class ReturnStatement : Statements
    {
        private Expression expr;
        private Statements stmts;
        public ReturnStatement(Expression expr, Statements stmts)
        {
            this.expr = expr;
            this.stmts = stmts;
        }
        public override bool ResolveNames(LexicalScope scope)
        {
            return expr.ResolveNames(scope);
        }
        public override void TypeCheck()
        {
            expr.TypeCheck();
            stmts.TypeCheck();
        }
    }

}