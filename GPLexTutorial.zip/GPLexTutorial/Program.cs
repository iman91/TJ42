﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPLexTutorial
{
    class Program
    {

        static void SemanticAnalysis(AST.Node root)
        {
            root.ResolveNames(null);
            root.TypeCheck();
        }
         

        static void Main(string[] args)
        {
            Console.WriteLine("Starting...");
            Scanner scanner = new Scanner(
            new System.IO.FileStream(args[0], System.IO.FileMode.Open));
            Parser parser = new Parser(scanner);
            Console.WriteLine("Parsing...");
            parser.Parse();

            if(Parser.root != null)
            {
                SemanticAnalysis(Parser.root);
            }
            Parser.root.DumpValue(0);
            Console.WriteLine("Finished...");
            Console.ReadLine();
        }
    }
}
