﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPlex.AST
{
    interface Declaration { }
    public abstract class TypeDeclaration : Node, Declaration { }
    public class CompilationUnit : Node
    {
        private List<TypeDeclaration> typedeclaration;
        public CompilationUnit(List<TypeDeclaration> typedeclaration) { this.typedeclaration = typedeclaration; }
        public override bool ResolveNames()
        {
            foreach (TypeDeclaration typedeclaration in typedeclaration)
            {
                if (!typedeclaration.ResolveNames()) return false;
            }
            return true;
        }
    }
    public enum ClassModifier { Static, Public }
    public class ClassDeclaration : TypeDeclaration
    {
        private List<ClassModifier> classmodifier;
        private string NameOfClass;
        private List<MethodDeclaration> methoddeclaration;
        public ClassDeclaration(List<ClassModifier> classmodifier, string NameOfClass, List<MethodDeclaration> methoddeclaration)
        { this.classmodifier = classmodifier; this.NameOfClass = NameOfClass; this.methoddeclaration = methoddeclaration; }
        public override bool ResolveNames()
        {
            foreach (MethodDeclaration methoddeclaration in methoddeclaration)
            {
                if (!methoddeclaration.ResolveNames()) return false;
            }
            return true;
        }
    }
    public enum MethodModifier { Static, Public }
    public class MethodDeclaration : Node, Declaration
    {
        private List<MethodModifier> methodmodifier;
        private List<MethodHeader> methodheader;
        private Statements statements;
        public MethodDeclaration(List<MethodModifier> methodmodifier, List<MethodHeader> methodheader, Statements statements)
        { this.methodmodifier = methodmodifier; this.methodheader = methodheader; this.statements = statements; }
        public override bool ResolveNames()
        {
            foreach (MethodHeader methodheader in methodheader)
            {
                if (!methodheader.ResolveNames()) return false;
            }
            return true;
        }
    }
    public class MethodHeader : Node
    {
        private string TypeofMethod;
        private List<MethodDeclarator> methoddeclarator;
        public MethodHeader(string TypeofMethod, List<MethodDeclarator> methoddeclarator)
        { this.TypeofMethod = TypeofMethod; this.methoddeclarator = methoddeclarator; }
        public override bool ResolveNames()
        {
            foreach (MethodDeclarator methoddeclarator in methoddeclarator)
            {
                if (!methoddeclarator.ResolveNames()) return false;
            }
            return true;
        }
    }

    public class FormalParameter : Node
    {
        private Type TypeofFP;
        private string NameofFP;
        public FormalParameter(Type TypeofFP, string NameofFP)
        { this.TypeofFP = TypeofFP; this.NameofFP = NameofFP; }
        public override bool ResolveNames()
        {
            return TypeofFP.ResolveNames();
        }
    }
    public class MethodDeclarator : Node
    {
        private string NameofMethod;
        private List<FormalParameter> formalparameter;
        public MethodDeclarator(string NameofMethod, List<FormalParameter> formalparameter)
        { this.NameofMethod = NameofMethod; this.formalparameter = formalparameter; }
        public override bool ResolveNames()
        {
            foreach (FormalParameter formalparameter in formalparameter)
            {
                if (!formalparameter.ResolveNames()) return false;
            }
            return true;
        }
    }
    public class LocalVariableDeclaration : Statements, Declaration
    {
        private Type TypeofLVD;
        private string NameofLVD;
        public LocalVariableDeclaration(Type TypeofLVD, string NameofLVD)
        { this.TypeofLVD = TypeofLVD; this.NameofLVD = NameofLVD; }
        public override bool ResolveNames()
        {
            return TypeofLVD.ResolveNames();
        }
    }
}
