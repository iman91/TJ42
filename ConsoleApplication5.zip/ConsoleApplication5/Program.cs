﻿public class HelloWorld
{
    public static void Main(string[] args)
    {
        int x;
        x = 42;
    }
}
